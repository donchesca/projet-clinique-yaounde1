from django import forms

class PronosticForm(forms.Form):
    frcar = forms.FloatField(
        label="Fréquence cardiaque (bpm)",
        min_value=30.0, max_value=250.0,
        widget=forms.NumberInput(attrs={'class': 'form-control', 'placeholder': 'Ex: 92'})
    )
    incar = forms.FloatField(
        label="Indice cardiaque",
        min_value=0.1, max_value=10.0,
        widget=forms.NumberInput(attrs={'class': 'form-control', 'placeholder': 'Ex: 1.90'})
    )
    pvent = forms.FloatField(
        label="Pression ventriculaire",
        min_value=0.0, max_value=100.0,
        widget=forms.NumberInput(attrs={'class': 'form-control', 'placeholder': 'Ex: 9'})
    )
    repul = forms.FloatField(
        label="Résistance pulmonaire",
        min_value=10.0, max_value=5000.0,
        widget=forms.NumberInput(attrs={'class': 'form-control', 'placeholder': 'Ex: 1281'})
    )
    prdia = forms.FloatField(
        label="Pression diastolique",
        min_value=0.0, max_value=150.0,
        widget=forms.NumberInput(attrs={'class': 'form-control', 'placeholder': 'Ex: 19'})
    )
    papul = forms.FloatField(
        label="Pression artérielle pulmonaire",
        min_value=0.0, max_value=150.0,
        widget=forms.NumberInput(attrs={'class': 'form-control', 'placeholder': 'Ex: 25'})
    )