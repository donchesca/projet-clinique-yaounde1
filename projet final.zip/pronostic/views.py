import os
import joblib
import pandas as pd
from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from django.conf import settings
from .forms import PronosticForm


MODEL_PATH = os.path.join(settings.BASE_DIR, 'saved_models', 'pipeline_logistique.joblib')

@login_required
def analyser_patient(request):
    resultat = None
    probabilite = None
    form = PronosticForm(request.POST or None)

    if request.method == 'POST' and form.is_valid():
        data_saisie = {
            'frcar': [form.cleaned_data['frcar']],
            'incar': [form.cleaned_data['incar']],
            'pvent': [form.cleaned_data['pvent']],
            'repul': [form.cleaned_data['repul']],
            'prdia': [form.cleaned_data['prdia']],
            'papul': [form.cleaned_data['papul']],
        }
        df_patient = pd.DataFrame(data_saisie)

        try:
            pipeline = joblib.load(MODEL_PATH)
            proba_classe_1 = pipeline.predict_proba(df_patient)[0][1]
            probabilite = round(proba_classe_1 * 100, 2)
            resultat = "Alerte : Risque Élevé" if proba_classe_1 >= 0.50 else "Profil Stable"
        except Exception as e:
            form.add_error(None, f"Erreur de traitement : {str(e)}")

    return render(request, 'pronostic/formulaire.html', {
        'form': form,
        'resultat': resultat,
        'probabilite': probabilite
    })

from django.contrib.auth import logout as django_logout
from django.shortcuts import redirect

def deconnexion_medecin(request):
    """
    Vue personnalisée pour déconnecter le médecin de manière sécurisée
    et le rediriger vers la page d'authentification.
    """
    django_logout(request)
    return redirect('login')
