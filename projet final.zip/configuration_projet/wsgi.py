import os
from django.core.wsgi import get_wsgi_application

# Liaison stricte avec les paramètres du projet de la clinique
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'configuration_projet.settings')

application = get_wsgi_application()
