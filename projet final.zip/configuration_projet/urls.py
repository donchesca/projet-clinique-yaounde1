from django.contrib import admin
from django.urls import path
from django.contrib.auth import views as auth_views
from pronostic import views as pronostic_views

urlpatterns = [
    path('admin/', admin.site.urls),
    
    # Page de connexion
    path('', auth_views.LoginView.as_view(template_name='registration/login.html'), name='login'),
    
    # Nouvelle route personnalisée pour la déconnexion
    path('logout/', pronostic_views.deconnexion_medecin, name='logout'),
    
    # Page du formulaire d'analyse
    path('analyse/', pronostic_views.analyser_patient, name='formulaire_clinique'),
]

