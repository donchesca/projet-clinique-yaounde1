

# 1.1. Données et méthodologie de modélisation supervisée
## 1.1.1 Exploration 
import pandas as pd
pd.options.mode.chained_assignment = None
data = pd.read_excel(r"C:\Users\GBK STORE\Documents\FORMATION DATA SCIENCE\PROJET FINAL\base_pronostic_stat_leaders.xlsx",
                     sheet_name ="donnees",
                     header=0)
                     
data.isnull().sum() # pour chaque variable, ça compte le nombre de valeur manquante
data.dtypes
data.isnull().sum() 

data = data.dropna(subset=["prono"]) 

## 1.2 analyse descriptive univariée des variables quantitatives
## 1.2.1 Univarié

# 1.2.1.1 Statistiques
print(data.frcar.describe().round(2))
print(data.incar.describe().round(2))
print(data.pvent.describe().round(2))
print(data.repul.describe().round(2))
print(data.prdia.describe().round(2))
print(data.papul.describe().round(2))
print(data.prono.describe().round(2))

variables = {
    "frcar": "Fréquence cardiaque",
    "incar": "Indice cardiaque",
    "pvent": "Pression ventriculaire",
    "repul": "Résistance pulmonaire",
    "prdia": "Pression diastolique",
    "papul": "Pression artérielle pulmonaire"
}

# Sélectionner les variables
donnees = data[list(variables.keys())].copy()

# Renommer les variables
donnees = donnees.rename(columns=variables)

# Construire le tableau d'analyse univariée
tableau_univarie = pd.DataFrame({
    "Effectif": donnees.count(),
    "Moyenne": donnees.mean(),
    "Écart-type": donnees.std(),
    "Médiane": donnees.median(),
    "Q1": donnees.quantile(0.25),
    "Q3": donnees.quantile(0.75),
    "Minimum": donnees.min(),
    "Maximum": donnees.max()
})

# Arrondir les résultats
tableau_univarie = tableau_univarie.round(2)


# 1.2.1.2 Graphiques

data["prono"][data["prono"] == 0] = "Non"
data["prono"][data["prono"] == 1] = "Oui"

import matplotlib.pyplot as plt
import seaborn as sns
sns.set_style("darkgrid")
def histogramme(variable, couleur, titre_graphique, titre_abcisse):
    sns.histplot(x = variable, data = data, bins = 9, kde = True, color = couleur)
    plt.title(titre_graphique, fontsize = 13, fontweight = "bold")
    plt.xlabel(titre_abcisse, fontsize = 12)
    plt.ylabel("Effectifs", fontsize = 12)
    plt.show()
        
histogramme("frcar", "green", "Répartition des patients selon la fréquence cardiaque", "Fréquence cardiaque")
histogramme("incar", "darkred", "Répartition des patients selon l'indice cardiaque", "Indice cardiaque")
histogramme("pvent", "goldenrod", "Répartition des patients selon la pression ventriculaire", "Pression ventriculaire")
histogramme("repul", "rosybrown", "Répartition des patients selon la résistance pulmonaire", "Résistance pulmonaire")
histogramme("prdia", "rosybrown", "Répartition des patients selon la pression diastolique", "Pression diastolique")
histogramme("papul", "green", "Répartition des patients selon la pression arterielle pulmonaire", "Pression arterielle pulmonaire")


sns.set_style("darkgrid")
plt.figure(figsize=(15, 10))
variables = ['frcar', 'incar', 'pvent', 'repul', 'prdia', 'papul']
titles = [
    "Répartition des patients selon la fréquence cardiaque", 
    "Répartition des patients selon l'indice cardiaque", 
    "Répartition des patients selon la pression ventriculaire", 
    "Répartition des patients selon la résistance pulmonaire", 
    "Répartition des patients selon la pression diastolique",
    "Répartition des patients selon la pression arterielle pulmonaire"
]
colors = ['green', 'darkred', 'goldenrod', 'rosybrown', 'purple', 'red']
x_labels = [
    "Fréquence cardiaque", 
    "Indice cardiaque", 
    "Pression ventriculaire", 
    "Résistance pulmonaire", 
    "Pression diastolique",
    "Pression arterielle pulmonaire"
]
for i, (var, title, color, x_label) in enumerate(zip(variables, titles, colors, x_labels)):
    plt.subplot(2, 3, i+1)  # 2 lignes, 3 colonnes, position i+1
    
    sns.histplot(x=var, data=data, bins=9, kde=True, color=color)
    
    plt.title(title, fontsize=11, fontweight="bold")
    plt.xlabel(x_label, fontsize=9)
    plt.ylabel("Effectifs", fontsize=9)

plt.tight_layout()
plt.suptitle("Distribution des variables quantitatives", fontsize=16, fontweight="bold", y=1.02)
plt.show()

## 1.2.2 bivarié
# Analyse de la relation entre le pronostic et les varibales quantitatives
# 1.2.2.1 Graphiques
def boites_moustaches(variable_x, variable_y, couleur, titre, titre_x, titre_y):
    sns.boxplot(x = variable_x, y = variable_y, data = data, palette = couleur)
    plt.title(titre, fontweight = "bold", fontsize = 15)
    plt.xlabel(titre_x, fontsize = 13)
    plt.ylabel(titre_y, fontsize = 13)
    plt.show()

boites_moustaches(data.prono, data.frcar, couleur = "seismic", titre = "Boîtes à moustaches de la population selon la fréquence cardiaque et la \n présence d'une maladie", titre_x = "Présence d'une maladie ", titre_y = "Fréquence cardiaque")
boites_moustaches(data.prono, data.incar, couleur = "seismic", titre = "Boîtes à moustaches de la population selon l' indice cardiaque et la présence d'une maladie", titre_x = "Présence d'une maladie", titre_y = "Indice cardiaque")
boites_moustaches(data.prono, data.pvent, couleur = "seismic", titre = "Boîtes à moustaches de la population selon la pression ventriculaire et la présence d'une maladie", titre_x = "Présence d'une maladie ", titre_y = "Pression ventriculaire")
boites_moustaches(data.prono, data.repul, couleur = "seismic", titre = "Boîtes à moustaches de la population selon la résistance pulmonaire et la \n présence d'une maladie", titre_x = "Présence d'une maladie", titre_y = "Résistance pulmonaire")
boites_moustaches(data.prono, data.prdia, couleur = "seismic", titre = "Boîtes à moustaches de la population selon la pression diastolique \n et la présence d'une maladie", titre_x = "Présence d'une maladie", titre_y = "Pression diastolique")
boites_moustaches(data.prono, data.papul, couleur = "seismic", titre = "Boîtes à moustaches de la population selon la pression arterielle pulmonaire \n et la présence d'une maladie", titre_x = "Présence d'une maladie", titre_y = "Pression arterielle pulmonaire")

# 2.2.1.1. Tests de comparaison de moyenne : test paramétrique de Student ou test non paramétrique de Mann-Whitney
    # Test de normalité de Shapiro-Wilk
        # H0 : L'échantillon suit une distribution normale (si p-value > 0,05)
        # H1 : L'échantillon ne suit pas une distribution normale (si p-value < 0,05)
from scipy.stats import shapiro
shapiro(data[data["prono"] == "Oui"].frcar) # H0
shapiro(data[data["prono"] == "Non"].frcar) # H0

shapiro(data[data["prono"] == "Oui"].incar) # H0
shapiro(data[data["prono"] == "Non"].incar) # H0

shapiro(data[data["prono"] == "Oui"].pvent) # H0
shapiro(data[data["prono"] == "Non"].pvent) # H0

shapiro(data[data["prono"] == "Oui"].repul) # H0
shapiro(data[data["prono"] == "Non"].repul) # H0

shapiro(data[data["prono"] == "Oui"].prdia) # H0
shapiro(data[data["prono"] == "Non"].prdia) # H0

shapiro(data[data["prono"] == "Oui"].papul) # H0
shapiro(data[data["prono"] == "Non"].papul) # H0


# Reformatage de la colonne target pour les tests de comparaison
data2 = data.copy(deep = True)
data2['prono'][data2['prono'] == "Non"] = 0
data2['prono'][data2['prono'] == "Oui"] = 1
# la mettre en format numérique
data2['prono'] = data2['prono'].astype('int64')

    # Test de Student (paramétrique)
        # H0 : Il n'y a pas de différence significative entre la moyenne des deux variables (si p-value > 0,05)
        # H1 : Il y a une différence significative entre la moyenne des deux variables (si p-value < 0,05)
from scipy.stats import ttest_ind
ttest_ind(data2.frcar, data2.prono) # H1
ttest_ind(data2.incar, data2.prono) # H1
ttest_ind(data2.pvent, data2.prono) # H1
ttest_ind(data2.repul, data2.prono) # H1
ttest_ind(data2.prdia, data2.prono) # H1
ttest_ind(data2.papul, data2.prono) # H1


# 1.2. Analyse multivariée exploratoire par analyse des correspondances multiples (ACM)

# 1.2.1 Categorisation des 6 variables quantitatives

data_acm = data.copy()
import numpy as np

# Variables quantitatives et préfixes des modalités

variables = {
    "frcar": "FC",
    "incar": "IC",
    "pvent": "PV",
    "repul": "RP",
    "prdia": "PD",
    "papul": "PAP"
} 


# Création de 4 catégories pour chaque variable
for var, prefixe in variables.items():

    # Calcul des quartiles sur les valeurs disponibles
    q1, q2, q3 = data_acm[var].quantile(
        [0.25, 0.50, 0.75]
    )

    print(f"\nVariable : {var}")
    print(f"Q1 = {q1:.2f}, Q2 = {q2:.2f}, Q3 = {q3:.2f}")

    # Vérifier que les seuils permettent 4 classes
    if len(set([q1, q2, q3])) < 3:
        print(
            f"ATTENTION : quartiles répétés pour {var}. "
            "Revoir la catégorisation."
        )
        continue

    # Créer les catégories
    data_acm[var + "_cat"] = pd.cut(
        data_acm[var],
        bins=[-np.inf, q1, q2, q3, np.inf],
        labels=[
            prefixe + "_faible",
            prefixe + "_moderé",
            prefixe + "_élévé",
            prefixe + "_critque"
        ],
        include_lowest=True
    )

    # Afficher les effectifs
    print("Effectifs par catégorie :")
    print(
        data_acm[var + "_cat"]
        .value_counts(sort=False, dropna=False)
    )
## Résultats de l'ACM et typologie qualitative

import prince

data_acm["prono"][data_acm["prono"] == 0] = "Non"
data_acm["prono"][data_acm["prono"] == 1] = "Oui"

variables_actives = [
    var + "_cat" for var in variables
    if var + "_cat" in data_acm.columns
]

variables_supplementaires = [
    "prono"
]


X = data_acm[variables_actives].astype("category")

mca = prince.MCA(
    n_components=5,
    n_iter=5,
    engine="sklearn",
    random_state=42,
    correction=None,
)

print("ACM ajustée avec succès sur", X.shape[0], "Patients et",
      sum(X[c].nunique() for c in variables_actives), "modalités actives.")

### recherche d'une modalité rare
for var in variables_actives:
    print(f"--- {var} ---")
    print((X[var].value_counts(normalize=True) * 100).round(1).astype(str) + " %")
    print()
    
### Tableau dijonctif complet

disjonctif = pd.get_dummies(data_acm[variables_actives], prefix_sep="__")
J = disjonctif.shape[1]
Q = len(variables_actives)
n = len(data_acm)

print(f"n = {n} individus, Q = {Q} variables actives, J = {J} modalités")
print("\nExtrait du tableau disjonctif complet (3 premiers Patients) :")
disjonctif.head(5).astype(int)

### Verification du tableau disjonctif complet

print("Somme par ligne (doit valoir Q = 6 pour chaque Patient) :")
print(disjonctif.head(3).sum(axis=1).values)
assert (disjonctif.sum(axis=1) == Q).all()
print("OK : toutes les lignes somment bien à Q.")

### tableau de Burt

Z = disjonctif.values.astype(float)
B = Z.T @ Z
burt = pd.DataFrame(B, index=disjonctif.columns, columns=disjonctif.columns).astype(int)

sous_bloc = burt.loc[
    [c for c in burt.columns if c.startswith("incar")],
    [c for c in burt.columns if c.startswith("repul")]
]
print("Bloc hors-diagonale de B : incar x repul")
print(sous_bloc)

print("\nVérification : c'est bien le tri croisé pandas classique")
print(pd.crosstab(data_acm["incar"], data_acm["repul"]))

### Masse des individus et des modalités

masses = disjonctif.sum(axis=0) / (n * Q)
masses = masses.sort_values(ascending=False)
print("Masses des modalités (c_j), triées :")
print((masses * 100).round(2).astype(str) + " %")
print("\nSomme des masses (doit valoir 1) :", masses.sum().round(6))

### Distance du Khi-deux entre deux individus

def distance_khi2(i1, i2, Z, masses_arr):
    diff2 = (Z[i1] - Z[i2]) ** 2
    return np.sqrt((diff2 / masses_arr).sum())

masses_arr = disjonctif.sum(axis=0).values / (n * Q)

i1, i2, i3 = 0, 1, 2
print(data_acm.loc[[i1, i2, i3], variables_actives])
print(f"\nd(star-up {i1}, star-up {i1+1}) = {distance_khi2(i1, i1, Z, masses_arr):.3f}  (un individu avec lui-même)")
print(f"d(star-up {i1}, star-up {i2})     = {distance_khi2(i1, i2, Z, masses_arr):.3f}")
print(f"d(star-up {i1}, star-up {i3})     = {distance_khi2(i1, i3, Z, masses_arr):.3f}")

### ACM avec prince

X = data_acm[variables_actives].astype("category")

mca = prince.MCA(
    n_components=5,
    n_iter=10,
    copy=True,
    check_input=True,
    engine="sklearn",
    random_state=42
)
mca = mca.fit(X)

coord_ind = mca.row_coordinates(X)
coord_ind.columns = [f"Axe_{i+1}" for i in range(coord_ind.shape[1])]

coord_mod = mca.column_coordinates(X)
coord_mod.columns = [f"Axe_{i+1}" for i in range(coord_mod.shape[1])]

print("Coordonnées des 5 premiers Patients :")
print(coord_ind.head())

### Valeurs propres et inertie expliqué

eigenvalues = mca.eigenvalues_
pct = mca.percentage_of_variance_
pct_cum = mca.cumulative_percentage_of_variance_

recap = pd.DataFrame({
    "Valeur propre": eigenvalues,
    "% inertie": pct,
    "% cumulé": pct_cum
}, index=[f"Axe {i+1}" for i in range(len(eigenvalues))])
print(recap.round(3))

I_theorique = (J - Q) / Q
print(f"\nInertie totale théorique (J-Q)/Q = ({J}-{Q})/{Q} = {I_theorique:.4f}")
print("(remarque : la somme ci-dessus ne vaut que sur les 5 axes calculés ; "
      "le rang maximal de l'ACM est J-Q =", J - Q, ")")

### Correction de Benzécri

lambdas = np.array(eigenvalues)
mask = lambdas > 1 / Q
lambdas_corrigees = np.where(mask, ((Q / (Q - 1)) ** 2) * (lambdas - 1 / Q) ** 2, 0.0)
pct_corrige = 100 * lambdas_corrigees / lambdas_corrigees.sum()

recap_benzecri = pd.DataFrame({
    "Valeur propre brute": lambdas.round(4),
    "Valeur propre corrigée (Benzécri)": lambdas_corrigees.round(4),
    "% inertie corrigée": pct_corrige.round(2),
    "% cumulé corrigé": np.cumsum(pct_corrige).round(2)
}, index=[f"Axe {i+1}" for i in range(len(lambdas))])
print(recap_benzecri)

# Vérification avec l'option native de prince
mca_benzecri = prince.MCA(n_components=5, correction="benzecri", random_state=42).fit(X)
print("\nVérification (prince, correction='benzecri') :", mca_benzecri.eigenvalues_.round(4).tolist())

### Eboulis des valeurs propres(brut et corrigé)

fig, axs = plt.subplots(1, 2, figsize=(12, 4.5))

axs[0].plot(range(1, 6), pct, marker="o", color="#2563eb")
axs[0].set_title("Éboulis : inertie brute (%)")
axs[0].set_xlabel("Axe")
axs[0].set_ylabel("% d'inertie")
axs[0].set_xticks(range(1, 6))

axs[1].plot(range(1, 6), pct_corrige, marker="o", color="#dc2626")
axs[1].set_title("Éboulis : inertie corrigée Benzécri (%)")
axs[1].set_xlabel("Axe")
axs[1].set_ylabel("% d'inertie corrigée")
axs[1].set_xticks(range(1, 6))

plt.tight_layout()
plt.show()

### Coordonnées, contributions et cos² des modalités

coord_mod = mca.column_coordinates(X)[[0, 1]]
coord_mod.columns = ["Axe_1", "Axe_2"]


n = X.shape[0]                 
Q = len(variables_actives)    

masses = {}
for var in variables_actives:
    effectifs = X[var].value_counts()
    for modalite, n_j in effectifs.items():
        nom_complet = f"{var}__{modalite}"
        masses[nom_complet] = n_j / (n * Q)

masses = pd.Series(masses, name="masse")

# --- Distance au centre d_j^2 (somme des coordonnées au carré sur TOUS

coord_mod_tous_axes = mca.column_coordinates(X)
d2 = (coord_mod_tous_axes ** 2).sum(axis=1)
d2.name = "d2_total"

# --- Contribution de chaque modalité à l'axe 1 et à l'axe 2 ---

lambda1, lambda2 = eigenvalues[0], eigenvalues[1]
ctr_axe1 = masses * coord_mod["Axe_1"] ** 2 / lambda1
ctr_axe2 = masses * coord_mod["Axe_2"] ** 2 / lambda2

# --- Cosinus carré 
cos2_axe1 = coord_mod["Axe_1"] ** 2 / d2
cos2_axe2 = coord_mod["Axe_2"] ** 2 / d2

tableau_modalites = pd.DataFrame({
    "Coord_Axe1": coord_mod["Axe_1"],
    "Coord_Axe2": coord_mod["Axe_2"],
    "Masse_%": (masses * 100).round(2),
    "Contribution_Axe1_%": (ctr_axe1 * 100).round(2),
    "Contribution_Axe2_%": (ctr_axe2 * 100).round(2),
    "cos2_Axe1": cos2_axe1.round(3),
    "cos2_Axe2": cos2_axe2.round(3),
}).sort_values("Coord_Axe1")

tableau_modalites

### Carte des modalités et nommage des axes

plt.figure(figsize=(9, 7))


plt.scatter(tableau_modalites["Coord_Axe1"], tableau_modalites["Coord_Axe2"],
            s=80, alpha=0.7, color="steelblue")

for modalite, ligne in tableau_modalites.iterrows():
    plt.text(ligne["Coord_Axe1"] + 0.02, ligne["Coord_Axe2"] + 0.02,
              modalite, fontsize=8)

# Lignes horizontale et verticale à l'origine, repères classiques du plan factoriel.
plt.axhline(0, color="grey", linewidth=0.8)
plt.axvline(0, color="grey", linewidth=0.8)
plt.xlabel("Axe 1")
plt.ylabel("Axe 2")
plt.title("ACM - Plan factoriel des modalités")
plt.grid(alpha=0.2)
plt.show()

###  Coordonnées des individus (nuage des Patients)

coord_ind = mca.row_coordinates(X)[[0, 1]]
coord_ind.columns = ["Axe_1", "Axe_2"]

plt.figure(figsize=(7, 6))
plt.scatter(coord_ind["Axe_1"], coord_ind["Axe_2"], alpha=0.15, s=10, color="darkorange")
plt.axhline(0, color="grey", linewidth=0.8)
plt.axvline(0, color="grey", linewidth=0.8)
plt.xlabel("Axe 1")
plt.ylabel("Axe 2")
plt.title("ACM - Plan factoriel des individus (90 patients)")
plt.grid(alpha=0.2)
plt.show()

# On affiche les 5 modalités les plus contributives à chaque axe,

print("Modalités les plus contributives - Axe 1 :")
print(tableau_modalites["Contribution_Axe1_%"].sort_values(ascending=False).head(5))
print()
print("Modalités les plus contributives - Axe 2 :")
print(tableau_modalites["Contribution_Axe2_%"].sort_values(ascending=False).head(5))

### Variables supplémentaires 

data_acm = data.copy()
data_acm["Axe_1"] = coord_ind["Axe_1"].values
data_acm["Axe_2"] = coord_ind["Axe_2"].values

# --- Barycentres par modalité pour chaque variable supplémentaire ---
# (moyenne de la coordonnée factorielle des individus portant la modalité)

for var in variables_supplementaires:
    print(f"--- Barycentres sur l'axe 1, par modalité de {var} ---")
    print(data_acm.groupby(var)["Axe_1"].mean().sort_values().round(3))
    print()
for var in variables_supplementaires:
    print(f"--- Barycentres sur l'axe 2, par modalité de {var} ---")
    print(data_acm.groupby(var)["Axe_2"].mean().sort_values().round(3))
    print()


rng_plot = np.random.default_rng(0)
jitter_x = rng_plot.normal(0, 0.02, n)
jitter_y = rng_plot.normal(0, 0.02, n)

fig, ax = plt.subplots(figsize=(8, 6.5))
couleurs = {"Oui": "#2563eb", "Non": "#d97706"}
for genre, c in couleurs.items():
    mask = (data_acm["prono"] == genre).values
    ax.scatter(coord_ind.loc[mask, "Axe_1"] + jitter_x[mask],
               coord_ind.loc[mask, "Axe_2"] + jitter_y[mask],
               s=10, alpha=0.25, color=c, label=genre, edgecolors="none")

# 2.3. Analyse des résultats économétriques : modèle de régression logistique binaire
# 2.3.0. Préparation des données pour la modélisation logistique binaire
# Transformation des variables qualitatives en variables binaires
data3 = pd.get_dummies(data, drop_first = True)
# Changement du nom de la colonne target
data3 = data3.rename(columns = {"prono_Oui" : "prono"})
data3.head()
# Séparation du jeu de données en jeu d'entraînement et en jeu de test
from sklearn.model_selection import train_test_split
x = data3.iloc[:,0:19] # On sélectionne les variables explicatives dans notre jeu de données
y = data3.prono # On séléctionne la variable d'intérêt
X_train, X_test, y_train, y_test = train_test_split(x, y, test_size = 0.2, random_state = 123) 
# X_train contient les données pour l'entraînement
# X_test contient les données pour le test
# y_train et y_test contiennent uniquement la colonne target pour l'entraînement et le test

# 2.3.1. Estimation du modèle d'entrainement
from sklearn.linear_model import LogisticRegression
RegressionLogistique = LogisticRegression(solver = "liblinear") # Ligne pour initialiser le modèle # l'argument "liblinear" qui est pratique pour les jeux de données qui ne sont pas très grands et vous le comprendrez mieux lorsque nous passerons au big-data
RegressionLogistique.fit(X_train, y_train) # Création du modèle de machine learning

# Afficher les coefficients de la régression logistique
coefficients = pd.DataFrame(
    {'Variable': X_train.columns,
     'Coefficient': RegressionLogistique.coef_[0],
     'Odds Ratio': np.exp(RegressionLogistique.coef_[0])
    })
coefficients
# Ajouter l'intercept
intercept_df = pd.DataFrame(
    {'Variable': ['Intercept'],
     'Coefficient': [RegressionLogistique.intercept_[0]],
     'Odds Ratio': [np.exp(RegressionLogistique.intercept_[0])]
    })
intercept_df
# Combiner les deux DataFrames
coefficients = pd.concat([intercept_df, coefficients], ignore_index=True)
# Trier par valeur absolue des coefficients pour voir les variables les plus influentes
coefficients_sorted = coefficients.sort_values(by='Coefficient', key=abs, ascending=False)
# Afficher les résultats
print(coefficients_sorted)
import os
print("Répertoire de travail actuel :", os.getcwd())
chemin_specifique = r"C:\Users\GBK STORE\Documents\FORMATION DATA SCIENCE\PROJET FINAL"  
coefficients_sorted.to_excel(os.path.join(chemin_specifique, 'coefficients_regression.xlsx'), index=False)
# Pour une interprétation plus visuelle
plt.figure(figsize=(10, 8))
plt.barh(coefficients_sorted['Variable'], coefficients_sorted['Coefficient'])
plt.xlabel('Coefficient Value')
plt.ylabel('Variable')
plt.title('Importance des variables dans le modèle de régression logistique')
plt.axvline(x=0, color='black', linestyle='-', alpha=0.3)
plt.tight_layout()
plt.show()

# 2.3.1. Robustesse du modèle
predictions = RegressionLogistique.predict(X_test)
comparaison = pd.DataFrame({"Valeurs réelles":y_test, "Valeurs prédites":predictions})
print(RegressionLogistique.score(X_test, y_test)) # score de prédiction = 83,33%
from sklearn.metrics import confusion_matrix
print(confusion_matrix(y_test, predictions))
import scikitplot as skplt 
skplt.metrics.plot_confusion_matrix(y_test, predictions)

import pandas as pd
from sklearn.metrics import confusion_matrix, ConfusionMatrixDisplay
import matplotlib.pyplot as plt

# 1. Calcul des prédictions et affichage du tableau de comparaison
predictions = RegressionLogistique.predict(X_test)
comparaison = pd.DataFrame({"Valeurs réelles": y_test, "Valeurs prédites": predictions})
print("Extrait des prédictions :")
print(comparaison.head())

# 2. Score global d'exactitude (Accuracy)
score = RegressionLogistique.score(X_test, y_test)
print(f"\nScore de prédiction (Accuracy) = {score * 100:.2f}%") # Affiche 83.33%

# 3. Calcul et affichage de la matrice de confusion textuelle
matrice_raw = confusion_matrix(y_test, predictions)
print("\nMatrice de confusion brute :")
print(matrice_raw)

# 4. Traçage propre de la matrice de confusion
plt.figure(figsize=(6, 5))
disp = ConfusionMatrixDisplay(confusion_matrix=matrice_raw, display_labels=["Non", "Oui"])
disp.plot(cmap=plt.cm.Blues, values_format='d')

plt.title("Matrice de confusion - Données de Test", fontsize=12, fontweight='bold', pad=15)
plt.xlabel("Pronostic Prédit", fontsize=10)
plt.ylabel("Pronostic Réel (Observé)", fontsize=10)
plt.grid(False) # Supprime les lignes de grille indésirables sur l'image

plt.tight_layout()
plt.show()


# Courbe ROC 
from sklearn.metrics import roc_auc_score
from sklearn.metrics import roc_curve
logit_roc_auc = roc_auc_score(y_test, RegressionLogistique.predict(X_test))
fpr, tpr, thresholds = roc_curve(y_test, RegressionLogistique.predict_proba(X_test)[:,1])
plt.figure()
plt.plot(fpr, tpr, label='Logistic Regression (area = %0.2f)' % logit_roc_auc)
plt.plot([0, 1], [0, 1],'r--')
plt.xlim([0.0, 1.0])
plt.ylim([0.0, 1.05])
plt.xlabel('Taux de faux positifs')
plt.ylabel('Taux de vrais positifs')
plt.title('Courbe ROC des prédictions de la modélisation', fontweight = "bold")
plt.legend(loc="lower right")
plt.show()

# Calcul de l'aire sous la courbe
from sklearn.metrics import auc
AireCourbe = auc(fpr, tpr)
print("L'aire sous la courbe est de :", AireCourbe ) 

# 6. Exportation automatique du pipeline pour l'infrastructure Django
import os
import joblib
from sklearn.linear_model import LogisticRegression

# 1. Nettoyage de la base (90 observations documentées)
data_clean = data.dropna(subset=['prono']).copy()
data3 = pd.get_dummies(data_clean, drop_first=True)
if "prono_Oui" in data3.columns:
    data3 = data3.rename(columns={"prono_Oui": "prono"})

# 2. SÉPARATION STRICTE : On supprime 'prono' ET 'malade' des variables explicatives (X)
X = data3.drop(columns=['prono', 'malade'], errors='ignore')
y = data3['prono'].astype(int)

# Vérification pour le jury : X ne doit contenir QUE les 6 constantes physiologiques
print("Variables d'entraînement conservées :", list(X.columns))

# 3. Entraînement avec le solveur liblinear
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=123)
RegressionLogistique = LogisticRegression(solver="liblinear")
RegressionLogistique.fit(X_train, y_train)

# 4. Exportation du modèle propre pour Django
chemin_target = r"C:\Users\GBK STORE\Documents\FORMATION DATA SCIENCE\PROJET FINAL\saved_models"
os.makedirs(chemin_target, exist_ok=True)
joblib.dump(RegressionLogistique, os.path.join(chemin_target, 'pipeline_logistique.joblib'))

print("✅ Modèle ré-entraîné et exporté sans les colonnes 'malade' et 'prono' !")